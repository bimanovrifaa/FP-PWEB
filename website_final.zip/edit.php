<?php
session_start();
include 'koneksi.php';
if($_SESSION['status'] != "login") header("location:login.php");

$id = $_GET['id'];
$data = mysqli_query($conn, "SELECT * FROM products WHERE id='$id'");
$row = mysqli_fetch_assoc($data);

if(isset($_POST['update'])) {
    $name = $_POST['name'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $is_available = $_POST['is_available'];

    // Cek apakah user ganti foto?
    $filename = $_FILES['foto']['name'];
    
    if($filename != "") {
        // JIKA GANTI FOTO
        $rand = rand();
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $xx = $rand.'_'.$filename;
        move_uploaded_file($_FILES['foto']['tmp_name'], 'uploads/'.$xx);
        $path_db = 'uploads/'.$xx;
        
        // Update query dengan gambar baru
        mysqli_query($conn, "UPDATE products SET name='$name', category='$category', price='$price', description='$description', image_url='$path_db', is_available='$is_available' WHERE id='$id'");
    } else {
        // JIKA TIDAK GANTI FOTO (Gambar tetap yg lama)
        mysqli_query($conn, "UPDATE products SET name='$name', category='$category', price='$price', description='$description', is_available='$is_available' WHERE id='$id'");
    }
    
    header("location:admin.php");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Edit Menu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-sm border-0 rounded-4">
                    <div class="card-body p-4">
                        <h4 class="fw-bold mb-4">Edit Menu</h4>
                        
                        <form method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label class="form-label">Nama Menu</label>
                                <input type="text" name="name" class="form-control" value="<?php echo $row['name']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Kategori</label>
                                <input type="text" name="category" class="form-control" value="<?php echo $row['category']; ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Harga</label>
                                <input type="number" name="price" class="form-control" value="<?php echo $row['price']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Deskripsi</label>
                                <textarea name="description" class="form-control" rows="3"><?php echo $row['description']; ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Status Ketersediaan</label>
                                <select name="is_available" class="form-select">
                                    <option value="1" <?php if($row['is_available'] == 1) echo 'selected'; ?>>Tersedia</option>
                                    <option value="0" <?php if($row['is_available'] == 0) echo 'selected'; ?>>Habis (Sold Out)</option>
                                </select>
                            </div>
                            
                            <div class="mb-4">
                                <label class="form-label d-block">Foto Saat Ini</label>
                                <img src="<?php echo $row['image_url']; ?>" width="100" class="mb-2 rounded">
                                <input type="file" name="foto" class="form-control">
                                <small class="text-muted">Biarkan kosong jika tidak ingin mengganti foto.</small>
                            </div>
                            
                            <div class="d-flex gap-2">
                                <a href="admin.php" class="btn btn-light w-50">Batal</a>
                                <button type="submit" name="update" class="btn btn-primary w-50">Update Menu</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>