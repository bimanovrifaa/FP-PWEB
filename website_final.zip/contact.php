<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kontak Kami - Tetra Coffee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <?php include 'navbar.php'; ?>

    <section class="container py-5 mt-5 text-center animate-up">
        <span class="badge badge-category mb-2">GET IN TOUCH</span>
        <h1 class="fw-bold display-5">KONTAK KAMI</h1>
        <div class="mx-auto mt-3" style="width: 80px; height: 4px; background: var(--accent-gold);"></div>
    </section>

    <section class="container mb-5 animate-up delay-100">
        <div class="row g-5">
            <div class="col-lg-5">
                <img src="https://images.unsplash.com/photo-1600093463592-8e36ae95ef56" class="contact-hero-img w-100 shadow-sm" alt="Tetra Store">
            </div>

            <div class="col-lg-7 d-flex flex-column justify-content-center">
                
                <div class="mb-4">
                    <div class="d-flex align-items-center mb-3">
                        <i class="bi bi-building fs-3 me-3 text-warning"></i>
                        <span class="text-muted fw-bold text-uppercase">Tetra Coffee HQ</span>
                    </div>
                    <hr class="text-warning opacity-100" style="height: 2px; width: 50%;">
                </div>

                <div class="contact-info-box mb-4">
                    <h5>SURABAYA PUSAT</h5>
                    <p class="text-muted mb-1">Jl. Tunjungan No. 45, Genteng, Surabaya</p>
                    <p class="text-muted">Telp: (+62) 812-3456-7890</p>
                </div>

                <div class="contact-info-box mb-4">
                    <h5>SURABAYA BARAT</h5>
                    <p class="text-muted mb-1">Jl. Raya Darmo Permai II No. 12, Surabaya</p>
                    <p class="text-muted">Telp: (+62) 812-9876-5432</p>
                </div>

                <div class="contact-info-box">
                    <h5>JAM OPERASIONAL</h5>
                    <p class="text-muted mb-0">Senin - Minggu: 07.00 - 23.00 WIB</p>
                </div>

            </div>
        </div>
    </section>

    <section class="border-top mt-5 animate-up delay-200">
        <div class="container">
            <div class="text-center py-5">
                <h3 class="fw-light text-muted mb-4">JEJARING KONTAK</h3>
                <div class="row justify-content-center">
                    
                    <div class="col-6 col-md-3 social-grid-item">
                        <i class="bi bi-instagram social-icon-lg"></i>
                        <div class="social-label mt-2">INSTAGRAM</div>
                        <a href="#" class="social-link">@TetraCoffeeSby</a>
                    </div>

                    <div class="col-6 col-md-3 social-grid-item">
                        <i class="bi bi-facebook social-icon-lg"></i>
                        <div class="social-label mt-2">FACEBOOK</div>
                        <a href="#" class="social-link">Tetra Coffee Indonesia</a>
                    </div>

                    <div class="col-6 col-md-3 social-grid-item">
                        <i class="bi bi-envelope social-icon-lg"></i>
                        <div class="social-label mt-2">EMAIL</div>
                        <a href="#" class="social-link">hello@tetracoffee.id</a>
                    </div>

                    <div class="col-6 col-md-3 social-grid-item">
                        <i class="bi bi-whatsapp social-icon-lg"></i>
                        <div class="social-label mt-2">WHATSAPP</div>
                        <a href="#" class="social-link">0812-3456-7890</a>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <footer class="bg-dark text-white text-center py-4">
        <p class="mb-0 small">&copy; 2025 Tetra Coffee Surabaya.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>