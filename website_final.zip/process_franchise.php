<?php
include 'koneksi.php';
if(isset($_POST['submit_franchise'])) {
    $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
    $city     = mysqli_real_escape_string($conn, $_POST['city']);
    $phone    = mysqli_real_escape_string($conn, $_POST['phone']);
    $email    = mysqli_real_escape_string($conn, $_POST['email']);
    $budget   = mysqli_real_escape_string($conn, $_POST['budget']);
    $reason   = mysqli_real_escape_string($conn, $_POST['reason']);

    $query = "INSERT INTO franchise_leads (fullname, phone, email, city, budget_range, reason) VALUES ('$fullname', '$phone', '$email', '$city', '$budget', '$reason')";
    
    if(mysqli_query($conn, $query)) {
        echo "<script>alert('Berhasil! Kami akan menghubungi Anda.'); window.location='index.php';</script>";
    } else {
        echo "<script>alert('Gagal.'); window.history.back();</script>";
    }
}
?>