<?php
include 'koneksi.php';
// Ambil 3 menu untuk Signature (Pastikan ada data di database)
$query = "SELECT * FROM products LIMIT 3";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Tetra Coffee Surabaya - Premium Coffee Experience</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <?php include 'navbar.php'; ?>

    <section class="hero" id="hero">
        <div class="text-center px-3 animate-up">
            <span class="badge bg-white text-dark rounded-pill px-3 py-2 mb-3 shadow-sm fw-bold tracking-wide">EST. 2025 SURABAYA</span>
            <h1 class="display-3 fw-bold mb-3 text-white">Taste the <span class="text-warning">Difference</span></h1>
            <p class="lead mb-4 text-white opacity-75" style="max-width: 600px; margin: 0 auto;">
                Nikmati kopi artisan terbaik dengan suasana nyaman di tengah hiruk pikuk kota.
            </p>
            <div class="d-flex justify-content-center gap-3">
                <a href="#menu" class="btn btn-light btn-lg px-4 rounded-pill fw-bold shadow-lg">Pesan Sekarang</a>
                <a href="full-menu.php" class="btn btn-outline-light btn-lg px-4 rounded-pill fw-bold">Lihat Menu</a>
            </div>
        </div>
    </section>

    <section class="container py-5" id="menu">
        <div class="text-center mb-5 animate-up delay-100">
            <h5 class="text-muted text-uppercase letter-spacing-2 small fw-bold">Pilihan Barista</h5>
            <h2 class="fw-bold display-6">Signature Collections</h2>
            <div class="mx-auto mt-2" style="width: 60px; height: 3px; background: var(--accent-gold);"></div>
        </div>

        <div class="row g-4">
            <?php 
            if(mysqli_num_rows($result) > 0) {
                while($row = mysqli_fetch_assoc($result)) { 
            ?>
                <div class="col-md-4 animate-up delay-200">
                    <div class="card menu-card h-100 position-relative">
                        
                        <div class="badge-overlay text-dark">
                            <i class="bi bi-star-fill text-warning"></i> Recommended
                        </div>

                        <a href="detail.php?id=<?php echo $row['id']; ?>" class="overflow-hidden">
                            <img src="<?php echo $row['image_url']; ?>" class="card-img-top" alt="<?php echo $row['name']; ?>">
                        </a>

                        <div class="card-body d-flex flex-column text-center pt-4">
                            <div class="small text-muted text-uppercase mb-1" style="font-size: 0.7rem; letter-spacing: 1px;">
                                <?php echo $row['category']; ?>
                            </div>

                            <h5 class="card-title fw-bold">
                                <a href="detail.php?id=<?php echo $row['id']; ?>" class="text-decoration-none text-dark stretched-link">
                                    <?php echo $row['name']; ?>
                                </a>
                            </h5>
                            
                            <p class="text-muted small flex-grow-1 px-2">
                                <?php echo substr($row['description'], 0, 60) . '...'; ?>
                            </p>
                            
                            <h5 class="text-primary fw-bold mb-3">Rp <?php echo number_format($row['price'], 0, ',', '.'); ?></h5>
                            
                            <div class="d-flex justify-content-center gap-2 position-relative" style="z-index: 5;">
                                <a href="detail.php?id=<?php echo $row['id']; ?>" class="btn btn-outline-dark rounded-pill px-4 btn-sm fw-bold">
                                    Lihat Detail
                                </a>
                                <button 
                                    class="card-icon-btn btn-quick-add" 
                                    data-name="<?php echo $row['name']; ?>"
                                    data-price="<?php echo $row['price']; ?>"
                                    title="Tambah Cepat">
                                    <i class="bi bi-plus-lg"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php 
                } 
            } else {
                echo "<p class='text-center'>Data menu belum tersedia.</p>";
            }
            ?>
        </div>

        <div class="text-center mt-5 animate-up">
            <a href="full-menu.php" class="btn btn-link text-dark text-decoration-none fw-bold">
                Lihat Semua Menu <i class="bi bi-arrow-right"></i>
            </a>
        </div>
    </section>

    <section class="bg-light py-5 my-5">
        <div class="container py-4">
            <div class="row align-items-center animate-up">
                <div class="col-md-6 mb-4 mb-md-0 position-relative">
                    <img src="https://images.unsplash.com/photo-1559925393-8be0ec4767c8" class="img-fluid rounded-4 shadow-lg w-100" alt="Cafe Vibes">
                </div>
                <div class="col-md-6 ps-md-5">
                    <h5 class="text-muted text-uppercase letter-spacing-2 small fw-bold">Tentang Kami</h5>
                    <h2 class="fw-bold mb-3 display-6">More Than Just Coffee.</h2>
                    <p class="text-muted lead fs-6">
                        Tetra Coffee hadir untuk mereka yang mencari ketenangan. Dimulai dari garasi kecil pada 2020, kini kami membawa filosofi 4 elemen kopi ke cangkir Anda.
                    </p>
                    <a href="about.php" class="btn btn-outline-dark rounded-pill px-4 mt-3">Baca Perjalanan Kami</a>
                </div>
            </div>
        </div>
    </section>

    <section class="container py-5 mb-5 animate-up">
        <div class="card bg-dark text-white rounded-4 overflow-hidden shadow-lg">
            <div class="row g-0">
                <div class="col-md-6 order-md-2">
                    <img src="https://images.unsplash.com/photo-1554118811-1e0d58224f24" class="w-100 h-100" style="object-fit: cover; min-height: 300px;" alt="Lokasi">
                </div>
                <div class="col-md-6 order-md-1 d-flex align-items-center">
                    <div class="p-5">
                        <h5 class="text-warning text-uppercase letter-spacing-2 small fw-bold mb-2">Mampir Yuk</h5>
                        <h2 class="fw-bold mb-3">Lokasi Kami</h2>
                        <p class="opacity-75 mb-4">
                            Ingin merasakan suasana Tetra secara langsung? Kunjungi gerai utama kami di pusat kota Surabaya. WiFi kencang, kopi nikmat.
                        </p>
                        <div class="d-flex flex-column gap-2 mb-4">
                            <div class="d-flex align-items-center gap-2">
                                <i class="bi bi-geo-alt-fill text-warning"></i> Jl. Tunjungan No. 45, Surabaya
                            </div>
                            <div class="d-flex align-items-center gap-2">
                                <i class="bi bi-clock-fill text-warning"></i> 07.00 - 23.00 WIB
                            </div>
                        </div>
                        <a href="contact.php" class="btn btn-light rounded-pill px-4 fw-bold">Lihat Detail Lokasi</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

<footer class="bg-dark text-white text-center py-4">
        <div class="container">
            <p class="mb-0 opacity-50 small">&copy; 2025 Tetra Coffee Surabaya. Crafted with Passion.</p>
            
            <div class="mt-3">
                <a href="login.php" class="text-white text-decoration-none opacity-25 small" style="font-size: 10px;">
                    <i class="bi bi-lock-fill"></i> Admin Login
                </a>
            </div>

        </div>
    </footer>

    <div class="offcanvas offcanvas-end" tabindex="-1" id="cartOffcanvas">
        <div class="offcanvas-header border-bottom">
            <h5 class="offcanvas-title fw-bold">Cart Anda</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body d-flex flex-column">
            <div id="cartItems" class="mb-3 flex-grow-1"><p class="text-muted text-center mt-4">Belum ada item.</p></div>
            <div class="mt-auto border-top pt-3">
                <div class="d-flex justify-content-between mb-3">
                    <strong class="h5">Total</strong><strong class="h5" id="cartTotal">Rp 0</strong>
                </div>
                <a href="order.php" class="btn btn-dark w-100 py-2 rounded-pill fw-bold">Checkout Sekarang</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // --- LOGIKA CART ---
        let cart = JSON.parse(localStorage.getItem('tetraCart')) || [];

        function updateCartUI() {
            const badge = document.getElementById('cartCount');
            badge.innerText = cart.length;
            if(cart.length > 0) {
                badge.classList.remove('d-none');
            } else {
                badge.classList.add('d-none');
            }

            const itemsEl = document.getElementById('cartItems');
            const totalEl = document.getElementById('cartTotal');
            
            if(cart.length === 0) {
                itemsEl.innerHTML = '<div class="text-center mt-5 text-muted"><i class="bi bi-cart-x display-1"></i><p class="mt-3">Keranjang kosong</p></div>';
                totalEl.innerText = 'Rp 0';
                return;
            }

            let html = '<ul class="list-group list-group-flush">';
            let total = 0;
            cart.forEach((item, index) => {
                total += parseInt(item.price);
                html += `<li class="list-group-item d-flex justify-content-between align-items-center px-0">
                    <div>
                        <div class="fw-semibold">${item.name}</div>
                        <div class="text-muted small">Rp ${parseInt(item.price).toLocaleString('id-ID')}</div>
                    </div>
                    <button class="btn btn-sm text-danger" onclick="removeFromCart(${index})"><i class="bi bi-trash"></i></button>
                </li>`;
            });
            html += '</ul>';
            
            itemsEl.innerHTML = html;
            totalEl.innerText = 'Rp ' + total.toLocaleString('id-ID');
            localStorage.setItem('tetraCart', JSON.stringify(cart));
        }

        function removeFromCart(index) {
            cart.splice(index, 1);
            updateCartUI();
        }

        // --- QUICK ADD BUTTON LOGIC ---
        document.querySelectorAll('.btn-quick-add').forEach(btn => {
            btn.addEventListener('click', function() {
                const name = this.getAttribute('data-name');
                const price = this.getAttribute('data-price');
                
                cart.push({name, price});
                updateCartUI();
                
                const originalHTML = this.innerHTML;
                this.innerHTML = '<i class="bi bi-check"></i>';
                this.style.background = 'var(--primary-dark)';
                this.style.color = 'white';
                
                const bsOffcanvas = new bootstrap.Offcanvas('#cartOffcanvas');
                bsOffcanvas.show();

                setTimeout(() => {
                    this.innerHTML = originalHTML;
                    this.style.background = '';
                    this.style.color = '';
                }, 1500);
            });
        });

        // Load awal
        updateCartUI();
    </script>
</body>
</html>