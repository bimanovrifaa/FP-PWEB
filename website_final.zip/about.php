<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tentang Kami - Tetra Coffee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <?php include 'navbar.php'; ?>

    <section class="py-5 mt-5 bg-light">
        <div class="container py-5 text-center animate-up">
            <span class="badge badge-category mb-3">OUR STORY</span>
            <h1 class="display-4 fw-bold mb-3">Di Balik Secangkir Tetra</h1>
            <p class="lead text-muted mx-auto" style="max-width: 700px;">
                Sebuah perjalanan dedikasi untuk menemukan keseimbangan sempurna antara alam, manusia, dan teknik penyeduhan.
            </p>
        </div>
    </section>

    <section class="container py-5">
        <div class="row align-items-center g-5">
            <div class="col-md-6 animate-up">
                <img src="Sejarah Kopi.jpg" class="img-fluid rounded-4 shadow-lg" alt="Sejarah Kopi">
            </div>
            <div class="col-md-6 animate-up delay-100">
                <h3 class="fw-bold mb-3">Bermula dari Garasi</h3>
                <p class="text-muted">
                    Tetra Coffee dimulai pada tahun 2020, di sebuah garasi kecil di sudut kota Surabaya. Nama <strong>"Tetra"</strong> diambil dari filosofi empat elemen dasar kopi: <em>Air, Biji, Suhu, dan Waktu.</em>
                </p>
                <p class="text-muted">
                    Kami percaya bahwa kopi yang enak bukan kebetulan, melainkan hasil dari presisi matematika dan sentuhan seni manusia. Mimpi kami sederhana: menyajikan kopi kelas dunia dengan kehangatan lokal khas Suroboyo.
                </p>
                
                <div class="row mt-4">
                    <div class="col-6">
                        <h2 class="fw-bold text-primary">5+</h2>
                        <small class="text-uppercase text-muted fw-bold">Tahun Pengalaman</small>
                    </div>
                    <div class="col-6">
                        <h2 class="fw-bold text-primary">15k+</h2>
                        <small class="text-uppercase text-muted fw-bold">Cangkir Terjual</small>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <section class="py-5 my-5">
        <div class="container">
            <div class="text-center mb-5 animate-up">
                <h2 class="fw-bold">Proses Kami</h2>
                <p class="text-muted">Bagaimana kami menjaga kualitas di setiap tegukan.</p>
            </div>
            
            <div class="row g-4">
                <div class="col-md-4 animate-up delay-100">
                    <div class="process-card text-center h-100">
                        <i class="bi bi-geo-alt process-icon"></i>
                        <h4 class="fw-bold">1. Sourcing</h4>
                        <p class="text-muted small">Kami bekerja sama langsung dengan petani kopi di Dampit dan Ijen untuk mendapatkan biji Arabica terbaik.</p>
                    </div>
                </div>
                <div class="col-md-4 animate-up delay-200">
                    <div class="process-card text-center h-100">
                        <i class="bi bi-fire process-icon"></i>
                        <h4 class="fw-bold">2. Roasting</h4>
                        <p class="text-muted small">Disangrai dengan profil *medium-roast* menggunakan mesin artisan untuk mengeluarkan aroma buah dan coklat.</p>
                    </div>
                </div>
                <div class="col-md-4 animate-up delay-200">
                    <div class="process-card text-center h-100">
                        <i class="bi bi-cup-hot process-icon"></i>
                        <h4 class="fw-bold">3. Brewing</h4>
                        <p class="text-muted small">Diseduh oleh barista bersertifikat dengan kalibrasi alat yang dilakukan setiap pagi demi konsistensi rasa.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="bg-dark text-white text-center py-4">
        <p class="mb-0 small">&copy; 2025 Tetra Coffee Surabaya.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>