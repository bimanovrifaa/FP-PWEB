<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "tetra_coffee_db";

// Bikin koneksi
$conn = mysqli_connect($host, $user, $pass, $db);

// Cek jika gagal
if (!$conn) {
    die("Koneksi Database Gagal: " . mysqli_connect_error());
}
?>