<?php
include 'koneksi.php';

$id = $_GET['id'];
$query = "SELECT * FROM products WHERE id = '$id'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

if(mysqli_num_rows($result) < 1) {
    echo "<script>alert('Menu tidak ditemukan!');window.location='index.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $row['name']; ?> - Tetra Coffee</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-light fixed-top shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="index.php">Tetra Coffee</a>
            <div class="ms-auto">
                <button class="btn btn-outline-dark position-relative rounded-pill px-3" data-bs-toggle="offcanvas" data-bs-target="#cartOffcanvas">
                    <i class="bi bi-cart3"></i> Cart 
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="cartCount">0</span>
                </button>
            </div>
        </div>
    </nav>

    <main class="container py-5 mt-5">
        <a href="full-menu.php" class="text-decoration-none text-muted mb-4 d-inline-block animate-up">
            <i class="bi bi-arrow-left"></i> Kembali ke Menu
        </a>

        <div class="row align-items-center g-5">
            
            <div class="col-md-6 animate-up">
                <div class="detail-img-box">
                    <img src="<?php echo $row['image_url']; ?>" class="img-fluid w-100" style="object-fit: cover; height: 550px;" alt="<?php echo $row['name']; ?>">
                </div>
            </div>

            <div class="col-md-6 animate-up delay-100">
                <div class="ps-md-4">
                    <span class="badge badge-category text-uppercase mb-3"><?php echo $row['category']; ?></span>
                    
                    <h1 class="display-4 fw-bold mb-2"><?php echo $row['name']; ?></h1>
                    
                    <h2 class="text-dark fw-bold mb-4">Rp <?php echo number_format($row['price'], 0, ',', '.'); ?></h2>
                    
                    <hr class="text-muted opacity-25 mb-4">

                    <p class="lead text-muted mb-5" style="line-height: 1.8; font-size: 1rem;">
                        <?php echo $row['description']; ?>
                        <br><br>
                        <em>Nikmati perpaduan rasa yang otentik, dibuat segar saat Anda memesan. Cocok untuk menemani waktu santai atau kerja Anda.</em>
                    </p>

                    <div class="d-flex align-items-center gap-3 mb-4">
                        
                        <div class="quantity-box">
                            <button class="btn-qty" onclick="updateQty(-1)">-</button>
                            <input type="number" id="qtyDisplay" class="qty-input" value="1" min="1" readonly>
                            <button class="btn-qty" onclick="updateQty(1)">+</button>
                        </div>

                        <button 
                            class="btn btn-dark btn-lg rounded-pill px-5 flex-grow-1"
                            id="addToCartBtn"
                            data-name="<?php echo $row['name']; ?>"
                            data-price="<?php echo $row['price']; ?>">
                            <i class="bi bi-bag-plus"></i> &nbsp; Masukkan Keranjang
                        </button>
                    </div>

                    <div class="small text-muted">
                        <i class="bi bi-check-circle-fill text-success"></i> Tersedia untuk Dine-in & Delivery
                    </div>
                </div>
            </div>

        </div>
    </main>

    <div class="offcanvas offcanvas-end" tabindex="-1" id="cartOffcanvas">
        <div class="offcanvas-header border-bottom">
            <h5 class="offcanvas-title fw-bold">Cart Anda</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body d-flex flex-column">
            <div id="cartItems" class="mb-3 flex-grow-1"><p class="text-muted text-center mt-4">Belum ada item.</p></div>
            <div class="mt-auto border-top pt-3">
                <div class="d-flex justify-content-between mb-3">
                    <strong class="h5">Total</strong><strong class="h5" id="cartTotal">Rp 0</strong>
                </div>
                <a href="order.php" class="btn btn-dark w-100 py-2 rounded-pill fw-bold">Checkout Sekarang</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // --- LOGIKA QUANTITY ---
        let currentQty = 1;
        const qtyDisplay = document.getElementById('qtyDisplay');

        function updateQty(change) {
            currentQty += change;
            if (currentQty < 1) currentQty = 1; // Minimal 1
            qtyDisplay.value = currentQty;
        }

        // --- LOGIKA CART (Diupdate agar support quantity banyak) ---
        let cart = JSON.parse(localStorage.getItem('tetraCart')) || [];

        function updateCartUI() {
            document.getElementById('cartCount').innerText = cart.length;
            const itemsEl = document.getElementById('cartItems');
            const totalEl = document.getElementById('cartTotal');
            
            if(cart.length === 0) {
                itemsEl.innerHTML = '<div class="text-center mt-5 text-muted"><i class="bi bi-cart-x display-1"></i><p class="mt-3">Keranjang kosong</p></div>';
                totalEl.innerText = 'Rp 0';
                return;
            }

            let html = '<ul class="list-group list-group-flush">';
            let total = 0;
            
            // Kita render cart sederhana di sidebar
            cart.forEach((item, index) => {
                total += parseInt(item.price);
                html += `<li class="list-group-item d-flex justify-content-between align-items-center px-0">
                    <div>
                        <div class="fw-semibold">${item.name}</div>
                        <div class="text-muted small">Rp ${parseInt(item.price).toLocaleString('id-ID')}</div>
                    </div>
                    <button class="btn btn-sm text-danger" onclick="removeFromCart(${index})"><i class="bi bi-trash"></i></button>
                </li>`;
            });
            html += '</ul>';
            
            itemsEl.innerHTML = html;
            totalEl.innerText = 'Rp ' + total.toLocaleString('id-ID');
            localStorage.setItem('tetraCart', JSON.stringify(cart));
        }

        function removeFromCart(index) {
            cart.splice(index, 1);
            updateCartUI();
        }

        // Event Listener Tombol Add to Cart
        document.getElementById('addToCartBtn').addEventListener('click', function() {
            const name = this.getAttribute('data-name');
            const price = this.getAttribute('data-price');
            
            // Loop sebanyak Quantity yang dipilih
            // Cara gampang: Push item ke array sebanyak angka di quantity
            for(let i = 0; i < currentQty; i++) {
                cart.push({name, price});
            }
            
            updateCartUI();
            
            // Animasi Tombol
            const originalHTML = this.innerHTML;
            this.innerHTML = '<i class="bi bi-check-lg"></i> Berhasil Ditambah!';
            this.classList.replace('btn-dark', 'btn-success');
            
            // Buka Cart otomatis biar user tau
            const bsOffcanvas = new bootstrap.Offcanvas('#cartOffcanvas');
            bsOffcanvas.show();

            setTimeout(() => {
                this.innerHTML = originalHTML;
                this.classList.replace('btn-success', 'btn-dark');
            }, 2000);
        });

        // Load awal
        updateCartUI();
    </script>
</body>
</html>