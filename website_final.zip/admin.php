<?php
session_start();
include 'koneksi.php';

// Cek apakah user sudah login (KEAMANAN)
if($_SESSION['status'] != "login"){
    header("location:login.php?pesan=belum_login");
}

// Logika Hapus Menu
if(isset($_GET['hapus'])){
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM products WHERE id='$id'");
    header("location:admin.php");
}

$query = "SELECT * FROM products ORDER BY id DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Dashboard Admin - Tetra Coffee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        /* Override style body khusus admin biar beda dikit */
        body { background-color: #f4f6f9; }
        .admin-table img { width: 60px; height: 60px; object-fit: cover; border-radius: 8px; }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">Admin Panel</a>
            <div class="ms-auto d-flex align-items-center">
                <span class="text-white me-3">Halo, <?php echo $_SESSION['username']; ?></span>
                <a href="logout.php" class="btn btn-sm btn-danger rounded-pill">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold">Kelola Menu</h2>
            <a href="tambah.php" class="btn btn-primary rounded-pill px-4"><i class="bi bi-plus-lg"></i> Tambah Menu Baru</a>
            <a href="tambah_cabang.php" class="btn btn-success rounded-pill px-4 ms-2"><i class="bi bi-geo-alt"></i> + Cabang</a>
            <a href="admin_franchise.php" class="btn btn-warning rounded-pill px-4 ms-2"><i class="bi bi-briefcase"></i> Cek Calon Mitra</a>
        </div>

        <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 admin-table">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4">No</th>
                                <th>Gambar</th>
                                <th>Nama Menu</th>
                                <th>Kategori</th>
                                <th>Harga</th>
                                <th>Status</th>
                                <th class="text-end pe-4">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $no = 1;
                            while($row = mysqli_fetch_assoc($result)) { 
                            ?>
                            <tr>
                                <td class="ps-4"><?php echo $no++; ?></td>
                                <td><img src="<?php echo $row['image_url']; ?>" alt="img"></td>
                                <td class="fw-bold"><?php echo $row['name']; ?></td>
                                <td><span class="badge bg-secondary text-uppercase"><?php echo $row['category']; ?></span></td>
                                <td>Rp <?php echo number_format($row['price']); ?></td>
                                <td>
                                    <?php if($row['is_available']) { ?>
                                        <span class="badge bg-success">Tersedia</span>
                                    <?php } else { ?>
                                        <span class="badge bg-danger">Habis</span>
                                    <?php } ?>
                                </td>
                                <td class="text-end pe-4">
                                    <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-warning text-white me-1"><i class="bi bi-pencil"></i></a>
                                    <a href="admin.php?hapus=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin mau hapus menu ini?')"><i class="bi bi-trash"></i></a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</body>
</html>