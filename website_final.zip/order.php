<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Checkout - Tetra Coffee</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">

    <script type="text/javascript"
        src="https://app.sandbox.midtrans.com/snap/snap.js"
        data-client-key="Mid-client-LmSJ0t8VQk4RBBjs"></script>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-light fixed-top shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="index.php">Tetra Coffee</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="full-menu.php"><i class="bi bi-arrow-left"></i> Kembali ke Menu</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <main class="container py-5 mt-5">
        <div class="row g-4 justify-content-center">
            
            <div class="col-lg-6">
                <div class="card checkout-card p-4 h-100">
                    <h4 class="fw-bold mb-4">Data Pemesan</h4>
                    <form id="paymentForm">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Nama Lengkap</label>
                            <input type="text" class="form-control" id="custName" required placeholder="Contoh: Budi Santoso">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Nomor HP / WhatsApp</label>
                            <input type="tel" class="form-control" id="custPhone" required placeholder="0812xxxxxxx">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Alamat Pengiriman / Meja</label>
                            <textarea class="form-control" id="custAddress" rows="3" required placeholder="Jalan Mawar No. 10..."></textarea>
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Catatan Tambahan</label>
                            <input type="text" class="form-control" id="custNote" placeholder="Less sugar, dll.">
                        </div>
                        
                        <div class="alert alert-light border small text-muted">
                            <i class="bi bi-shield-lock-fill"></i> Pembayaran Test Mode (Sandbox).
                        </div>

                        <button type="submit" class="btn btn-dark w-100 py-3 rounded-pill fw-bold" id="payButton">
                            Bayar Sekarang <i class="bi bi-credit-card-2-front ms-2"></i>
                        </button>
                    </form>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="card checkout-card p-4">
                    <h4 class="fw-bold mb-4">Ringkasan Pesanan</h4>
                    <div class="table-responsive">
                        <table class="table table-borderless align-middle">
                            <tbody id="checkoutTableBody"></tbody>
                            <tfoot class="border-top">
                                <tr>
                                    <td class="fw-bold pt-3 fs-5">Total Bayar</td>
                                    <td class="fw-bold pt-3 text-end fs-5 text-primary" id="checkoutTotal">Rp 0</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div id="emptyCartMessage" class="d-none text-center py-5">
                        <p class="text-muted mt-3">Keranjang Anda kosong.</p>
                        <a href="full-menu.php" class="btn btn-outline-dark rounded-pill px-4">Pilih Menu Dulu</a>
                    </div>
                </div>
            </div>

        </div>
    </main>

    <footer class="text-center py-4 mt-5">
        <div class="container">
            <p class="mb-0 text-muted small">&copy; 2025 Tetra Coffee Surabaya.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let cart = JSON.parse(localStorage.getItem('tetraCart')) || [];
        const tableBody = document.getElementById('checkoutTableBody');
        const totalEl = document.getElementById('checkoutTotal');
        const emptyMsg = document.getElementById('emptyCartMessage');
        const form = document.getElementById('paymentForm');
        const payButton = document.getElementById('payButton');

        function renderCheckout() {
            if (cart.length === 0) {
                tableBody.innerHTML = '';
                emptyMsg.classList.remove('d-none');
                payButton.disabled = true;
                payButton.innerText = 'Keranjang Kosong';
                return;
            }

            let html = '';
            let grandTotal = 0;
            const counts = {};
            
            cart.forEach(item => {
                if (!counts[item.name]) counts[item.name] = { ...item, qty: 0 };
                counts[item.name].qty += 1;
            });

            for (const key in counts) {
                const item = counts[key];
                const subtotal = item.price * item.qty;
                grandTotal += subtotal;
                html += `<tr><td><div class="fw-bold">${item.name}</div><small class="text-muted">${item.qty} x Rp ${parseInt(item.price).toLocaleString('id-ID')}</small></td><td class="text-end fw-semibold">Rp ${subtotal.toLocaleString('id-ID')}</td></tr>`;
            }

            tableBody.innerHTML = html;
            totalEl.innerText = 'Rp ' + grandTotal.toLocaleString('id-ID');
        }

        renderCheckout();

        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            if (cart.length === 0) { alert("Keranjang kosong!"); return; }

            payButton.disabled = true;
            payButton.innerHTML = 'Memproses...';

            let grandTotal = 0;
            cart.forEach(item => { grandTotal += parseInt(item.price); });

            const orderData = {
                name: document.getElementById('custName').value,
                phone: document.getElementById('custPhone').value,
                address: document.getElementById('custAddress').value,
                note: document.getElementById('custNote').value,
                total: grandTotal,
                items: cart
            };

            try {
                const response = await fetch('process_payment.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(orderData)
                });
                const result = await response.json();

                if(result.error) {
                    alert("Error: " + (result.details ? JSON.stringify(result.details) : result.error));
                    payButton.disabled = false;
                    payButton.innerHTML = 'Bayar Sekarang';
                    return;
                }

                window.snap.pay(result.token, {
                    onSuccess: function(result){
                        alert("Pembayaran Berhasil!");
                        localStorage.removeItem('tetraCart'); 
                        window.location.href = 'index.php';   
                    },
                    onPending: function(result){
                        alert("Menunggu pembayaran!");
                        localStorage.removeItem('tetraCart');
                        window.location.href = 'index.php';
                    },
                    onError: function(result){
                        alert("Pembayaran gagal!");
                        payButton.disabled = false;
                        payButton.innerHTML = 'Bayar Sekarang';
                    },
                    onClose: function(){
                        alert('Anda menutup popup pembayaran.');
                        payButton.disabled = false;
                        payButton.innerHTML = 'Bayar Sekarang';
                    }
                });

            } catch (error) {
                console.error(error);
                alert("Gagal menghubungi server.");
                payButton.disabled = false;
                payButton.innerHTML = 'Bayar Sekarang';
            }
        });
    </script>
</body>
</html>