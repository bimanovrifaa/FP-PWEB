<nav class="navbar navbar-expand-lg navbar-light fixed-top shadow-sm bg-white">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php">Tetra Coffee</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="nav">
            <ul class="navbar-nav ms-auto align-items-center">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="about.php">Tentang</a></li>
                <li class="nav-item"><a class="nav-link" href="full-menu.php">Menu</a></li>
                
                <li class="nav-item"><a class="nav-link" href="locations.php">Lokasi</a></li>
                <li class="nav-item"><a class="nav-link" href="franchise.php">Franchise</a></li>
                
                <li class="nav-item"><a class="nav-link" href="contact.php">Kontak</a></li>
                
                <li class="nav-item ms-2">
                     <a href="order.php" class="btn btn-dark text-white px-4 rounded-pill">Order Online</a>
                </li>
            </ul>
        </div>
    </div>
</nav>