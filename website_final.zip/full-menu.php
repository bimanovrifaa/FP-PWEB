<?php
include 'koneksi.php';

// --- LOGIKA PENCARIAN & FILTER ---
$whereClause = "";

// 1. Cek jika ada pencarian nama (Keyword)
if(isset($_GET['keyword']) && $_GET['keyword'] != "") {
    $keyword = mysqli_real_escape_string($conn, $_GET['keyword']);
    $whereClause .= " AND name LIKE '%$keyword%'";
}

// 2. Cek jika ada filter kategori
if(isset($_GET['category']) && $_GET['category'] != "") {
    $cat = mysqli_real_escape_string($conn, $_GET['category']);
    $whereClause .= " AND category = '$cat'";
}

$query = "SELECT * FROM products WHERE 1=1 $whereClause";
$result = mysqli_query($conn, $query);

$selectedCat = isset($_GET['category']) ? $_GET['category'] : '';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Full Menu - Tetra Coffee</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        /* CSS Tambahan Khusus Search Bar agar rapi */
        .search-container { max-width: 600px; margin: 0 auto; }
        .search-input { border-radius: 50px 0 0 50px; border: 1px solid #ddd; padding-left: 20px; border-right: none; }
        .search-input:focus { box-shadow: none; border-color: var(--primary-dark); }
        .search-btn { border-radius: 0 50px 50px 0; padding-left: 20px; padding-right: 20px; border: 1px solid var(--primary-dark); }
        
        .cat-scroll {
            overflow-x: auto; white-space: nowrap; padding-bottom: 10px;
            -ms-overflow-style: none; scrollbar-width: none;
        }
        .cat-scroll::-webkit-scrollbar { display: none; }
    </style>
</head>
<body>

    <?php include 'navbar.php'; ?>

    <header class="page-header animate-up">
        <div class="container">
            <span class="badge bg-warning text-dark mb-2">OUR SELECTION</span>
            <h1 class="display-4">Daftar Menu</h1>
            <p class="lead mb-0">Temukan rasa favoritmu hari ini.</p>
        </div>
    </header>

    <main class="container mb-5">
        
        <div class="mb-5 animate-up delay-100">
            <form action="" method="GET" class="search-container d-flex mb-4 shadow-sm rounded-pill">
                <?php if($selectedCat != '') { ?>
                    <input type="hidden" name="category" value="<?php echo $selectedCat; ?>">
                <?php } ?>
                <input type="text" name="keyword" class="form-control search-input py-3" placeholder="Cari menu (misal: Latte...)" value="<?php echo isset($_GET['keyword']) ? $_GET['keyword'] : ''; ?>">
                <button type="submit" class="btn btn-dark search-btn"><i class="bi bi-search"></i> Cari</button>
            </form>

            <div class="d-flex justify-content-center gap-2 cat-scroll">
                <a href="full-menu.php" class="btn rounded-pill px-4 py-2 <?php echo ($selectedCat == '') ? 'btn-dark' : 'btn-outline-dark border-0 bg-light'; ?>">Semua</a>
                <a href="full-menu.php?category=Coffee" class="btn rounded-pill px-4 py-2 <?php echo ($selectedCat == 'Coffee') ? 'btn-dark' : 'btn-outline-dark border-0 bg-light'; ?>">Coffee</a>
                <a href="full-menu.php?category=Signature Coffee" class="btn rounded-pill px-4 py-2 <?php echo ($selectedCat == 'Signature Coffee') ? 'btn-dark' : 'btn-outline-dark border-0 bg-light'; ?>">Signature</a>
                <a href="full-menu.php?category=Mocktail" class="btn rounded-pill px-4 py-2 <?php echo ($selectedCat == 'Mocktail') ? 'btn-dark' : 'btn-outline-dark border-0 bg-light'; ?>">Mocktail</a>
                <a href="full-menu.php?category=Food" class="btn rounded-pill px-4 py-2 <?php echo ($selectedCat == 'Food') ? 'btn-dark' : 'btn-outline-dark border-0 bg-light'; ?>">Food</a>
                 <a href="full-menu.php?category=Tea" class="btn rounded-pill px-4 py-2 <?php echo ($selectedCat == 'Tea') ? 'btn-dark' : 'btn-outline-dark border-0 bg-light'; ?>">Tea</a>
            </div>
        </div>
        
        <div class="row g-4">
            <?php 
            if(mysqli_num_rows($result) > 0) {
                while($row = mysqli_fetch_assoc($result)) { 
            ?>
            <div class="col-md-6 col-lg-4 animate-up delay-200">
                <div class="card menu-card h-100 position-relative">
                    <a href="detail.php?id=<?php echo $row['id']; ?>" class="overflow-hidden">
                        <img src="<?php echo $row['image_url']; ?>" class="card-img-top" alt="<?php echo $row['name']; ?>">
                    </a>
                    
                    <div class="card-body d-flex flex-column">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <div>
                                <div class="menu-badge"><?php echo $row['category']; ?></div>
                                <h5 class="card-title mb-0">
                                    <a href="detail.php?id=<?php echo $row['id']; ?>" class="text-decoration-none text-dark"><?php echo $row['name']; ?></a>
                                </h5>
                            </div>
                            <span class="price-tag">Rp <?php echo number_format($row['price'], 0, ',', '.'); ?></span>
                        </div>
                        <p class="card-text text-muted flex-grow-1 small">
                            <?php echo substr($row['description'], 0, 80) . '...'; ?>
                        </p>
                        
                        <button 
                            class="btn btn-dark btn-add-cart mt-2 w-100 rounded-pill"
                            data-name="<?php echo $row['name']; ?>"
                            data-price="<?php echo $row['price']; ?>">
                            <i class="bi bi-plus-lg"></i> Tambah ke Cart
                        </button>
                    </div>
                </div>
            </div>
            <?php 
                } 
            } else {
                echo '
                <div class="col-12 text-center py-5">
                    <i class="bi bi-cup-hot display-1 text-muted opacity-25"></i>
                    <h4 class="mt-3 fw-bold text-muted">Menu tidak ditemukan</h4>
                    <p class="text-muted">Coba kata kunci lain atau reset filter.</p>
                    <a href="full-menu.php" class="btn btn-outline-dark rounded-pill">Reset Pencarian</a>
                </div>';
            }
            ?> 
        </div>
    </main>

    <footer class="bg-dark text-white text-center py-4">
        <p class="mb-0 opacity-50 small">&copy; 2025 Tetra Coffee Surabaya.</p>
    </footer>

    <div class="offcanvas offcanvas-end" tabindex="-1" id="cartOffcanvas">
        <div class="offcanvas-header border-bottom">
            <h5 class="offcanvas-title fw-bold">Cart Anda</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body d-flex flex-column">
            <div id="cartItems" class="mb-3 flex-grow-1"><p class="text-muted text-center mt-4">Belum ada item.</p></div>
            <div class="mt-auto border-top pt-3">
                <div class="d-flex justify-content-between mb-3">
                    <strong class="h5">Total</strong><strong class="h5" id="cartTotal">Rp 0</strong>
                </div>
                <a href="order.php" class="btn btn-dark w-100 py-2 rounded-pill fw-bold">Checkout Sekarang</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // LOGIKA CART (Sama seperti sebelumnya)
        let cart = JSON.parse(localStorage.getItem('tetraCart')) || [];

        function updateCartUI() {
            const badge = document.getElementById('cartCount');
            badge.innerText = cart.length;
            if(cart.length > 0) badge.classList.remove('d-none');
            else badge.classList.add('d-none');

            const itemsEl = document.getElementById('cartItems');
            const totalEl = document.getElementById('cartTotal');
            
            if(cart.length === 0) {
                itemsEl.innerHTML = '<div class="text-center mt-5 text-muted"><i class="bi bi-cart-x display-1"></i><p class="mt-3">Keranjang kosong</p></div>';
                totalEl.innerText = 'Rp 0';
                return;
            }

            let html = '<ul class="list-group list-group-flush">';
            let total = 0;
            cart.forEach((item, index) => {
                total += parseInt(item.price);
                html += `<li class="list-group-item d-flex justify-content-between align-items-center px-0">
                    <div>
                        <div class="fw-semibold">${item.name}</div>
                        <div class="text-muted small">Rp ${parseInt(item.price).toLocaleString('id-ID')}</div>
                    </div>
                    <button class="btn btn-sm text-danger" onclick="removeFromCart(${index})"><i class="bi bi-trash"></i></button>
                </li>`;
            });
            html += '</ul>';
            
            itemsEl.innerHTML = html;
            totalEl.innerText = 'Rp ' + total.toLocaleString('id-ID');
            localStorage.setItem('tetraCart', JSON.stringify(cart));
        }

        function removeFromCart(index) {
            cart.splice(index, 1);
            updateCartUI();
        }

        document.querySelectorAll('.btn-add-cart').forEach(btn => {
            btn.addEventListener('click', function() {
                const name = this.getAttribute('data-name');
                const price = this.getAttribute('data-price');
                cart.push({name, price});
                updateCartUI();
                
                const originalText = this.innerHTML;
                this.innerHTML = '<i class="bi bi-check"></i>';
                this.classList.replace('btn-dark', 'btn-success');
                setTimeout(() => {
                    this.innerHTML = originalText;
                    this.classList.replace('btn-success', 'btn-dark');
                }, 1000);
            });
        });

        updateCartUI();
    </script>
</body>
</html>