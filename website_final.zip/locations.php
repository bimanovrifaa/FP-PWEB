<?php include 'koneksi.php'; 
$query = "SELECT * FROM branches ORDER BY id DESC";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Lokasi Outlet - Tetra Coffee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        .branch-card { border: none; border-radius: 16px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.05); transition: 0.3s; height: 100%; }
        .branch-card:hover { transform: translateY(-5px); box-shadow: 0 15px 40px rgba(0,0,0,0.1); }
        .branch-img { height: 200px; object-fit: cover; width: 100%; }
    </style>
</head>
<body>
    <?php include 'navbar.php'; // Nanti kita buat file navbar terpisah biar gampang ?>
    
    <main class="container py-5 mt-5">
        <div class="text-center mb-5 animate-up">
            <span class="badge bg-warning text-dark mb-2">OUR FOOTPRINT</span>
            <h1 class="fw-bold display-5">Temukan Tetra Terdekat</h1>
        </div>
        <div class="row g-4">
            <?php while($row = mysqli_fetch_assoc($result)) { ?>
            <div class="col-md-4 animate-up delay-100">
                <div class="card branch-card">
                    <img src="<?php echo $row['image_url']; ?>" class="branch-img" alt="Foto Toko">
                    <div class="card-body p-4 d-flex flex-column">
                        <div class="mb-2"><span class="badge bg-light text-dark border"><i class="bi bi-geo-alt-fill text-danger"></i> <?php echo $row['city']; ?></span></div>
                        <h4 class="card-title fw-bold mb-2"><?php echo $row['name']; ?></h4>
                        <p class="text-muted small flex-grow-1"><?php echo $row['address']; ?></p>
                        <a href="<?php echo $row['maps_link']; ?>" target="_blank" class="btn btn-outline-dark w-100 rounded-pill mt-3"><i class="bi bi-map"></i> Petunjuk Arah</a>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>