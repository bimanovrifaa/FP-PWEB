<?php
session_start();
include 'koneksi.php';

// Cek login
if($_SESSION['status'] != "login"){
    header("location:login.php");
    exit;
}

// Ambil data leads
$query = "SELECT * FROM franchise_leads ORDER BY id DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Calon Mitra - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f4f6f9; font-family: 'Poppins', sans-serif; }
    </style>
</head>
<body>
    
    <div class="container py-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold">Data Pengajuan Franchise</h2>
            <a href="admin.php" class="btn btn-outline-dark rounded-pill">
                <i class="bi bi-arrow-left"></i> Kembali ke Dashboard
            </a>
        </div>

        <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="bg-dark text-white">
                            <tr>
                                <th class="p-3">Tanggal</th>
                                <th>Nama & Kontak</th>
                                <th>Lokasi & Budget</th>
                                <th>Alasan</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if(mysqli_num_rows($result) > 0) {
                                while($row = mysqli_fetch_assoc($result)) { 
                            ?>
                            <tr>
                                <td class="p-3 small text-muted"><?php echo $row['created_at']; ?></td>
                                <td>
                                    <strong class="text-dark"><?php echo $row['fullname']; ?></strong><br>
                                    <div class="small text-muted">
                                        <i class="bi bi-whatsapp"></i> <?php echo $row['phone']; ?><br>
                                        <i class="bi bi-envelope"></i> <?php echo $row['email']; ?>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-info text-dark mb-1"><i class="bi bi-geo-alt"></i> <?php echo $row['city']; ?></span><br>
                                    <small class="text-success fw-bold"><?php echo $row['budget_range']; ?></small>
                                </td>
                                <td>
                                    <div class="text-muted small" style="max-width: 250px;">
                                        <?php echo substr($row['reason'], 0, 80) . '...'; ?>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-warning text-dark text-uppercase"><?php echo $row['status']; ?></span>
                                    <div class="mt-2">
                                        <a href="https://wa.me/<?php echo preg_replace('/^0/', '62', $row['phone']); ?>" target="_blank" class="btn btn-sm btn-success rounded-pill px-3">
                                            <i class="bi bi-whatsapp"></i> Hubungi
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php 
                                } 
                            } else {
                                echo "<tr><td colspan='5' class='text-center py-5 text-muted'>Belum ada data calon mitra yang masuk.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>