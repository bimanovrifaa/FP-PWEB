<?php
session_start();
include 'koneksi.php';
if($_SESSION['status'] != "login") header("location:login.php");

if(isset($_POST['submit'])) {
    $name = $_POST['name'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $description = $_POST['description'];

    // LOGIKA UPLOAD GAMBAR
    $rand = rand();
    $filename = $_FILES['foto']['name'];
    $ukuran = $_FILES['foto']['size'];
    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    
    // Cek ekstensi (hanya boleh gambar)
    if(!in_array($ext, ['png','jpg','jpeg','webp'])) {
        echo "<script>alert('File harus format gambar (PNG, JPG)!');</script>";
    } else {
        // Nama file baru: uploads/12345_namagambar.jpg
        $xx = $rand.'_'.$filename;
        move_uploaded_file($_FILES['foto']['tmp_name'], 'uploads/'.$xx);
        
        // Simpan path lengkap ke database
        $path_db = 'uploads/'.$xx;

        mysqli_query($conn, "INSERT INTO products (name, category, price, description, image_url) VALUES ('$name','$category','$price','$description','$path_db')");
        header("location:admin.php");
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Tambah Menu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-sm border-0 rounded-4">
                    <div class="card-body p-4">
                        <h4 class="fw-bold mb-4">Tambah Menu Baru</h4>
                        
                        <form method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label class="form-label">Nama Menu</label>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Kategori</label>
                                <select name="category" class="form-select">
                                    <option value="Coffee">Coffee</option>
                                    <option value="Signature Coffee">Signature Coffee</option>
                                    <option value="Mocktail">Mocktail</option>
                                    <option value="Food">Food</option>
                                    <option value="Tea">Tea</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Harga (Angka saja)</label>
                                <input type="number" name="price" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Deskripsi</label>
                                <textarea name="description" class="form-control" rows="3"></textarea>
                            </div>
                            <div class="mb-4">
                                <label class="form-label">Upload Foto</label>
                                <input type="file" name="foto" class="form-control" required>
                                <small class="text-muted">Format: JPG, PNG, WEBP. Max 2MB.</small>
                            </div>
                            
                            <div class="d-flex gap-2">
                                <a href="admin.php" class="btn btn-light w-50">Batal</a>
                                <button type="submit" name="submit" class="btn btn-primary w-50">Simpan Menu</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>