<?php
session_start();
include 'koneksi.php';

// Cek login
if($_SESSION['status'] != "login"){
    header("location:login.php");
    exit;
}

if(isset($_POST['submit'])) {
    $name = $_POST['name'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $maps_link = $_POST['maps_link'];

    // Logic Upload Foto
    $filename = $_FILES['foto']['name'];
    $tmp_name = $_FILES['foto']['tmp_name'];
    
    // Cek ada gambar gak
    if($filename != "") {
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $new_filename = uniqid() . '.' . $ext;
        $upload_path = 'uploads/' . $new_filename;

        if(move_uploaded_file($tmp_name, $upload_path)) {
            $query = "INSERT INTO branches (name, address, city, maps_link, image_url) VALUES ('$name', '$address', '$city', '$maps_link', '$upload_path')";
            
            if(mysqli_query($conn, $query)) {
                echo "<script>alert('Cabang berhasil ditambahkan!');window.location='admin.php';</script>";
            } else {
                echo "Error Database: " . mysqli_error($conn);
            }
        } else {
            echo "Gagal upload gambar.";
        }
    } else {
        echo "Harap pilih foto toko.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Tambah Cabang Baru</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>body { background-color: #f4f6f9; }</style>
</head>
<body class="d-flex align-items-center justify-content-center" style="min-height: 100vh;">
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-sm border-0 rounded-4">
                    <div class="card-header bg-white border-0 pt-4 px-4 text-center">
                        <h4 class="fw-bold mb-0">Input Cabang Baru</h4>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Nama Cabang</label>
                                <input type="text" name="name" class="form-control" placeholder="Contoh: Tetra Coffee Manyar" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Kota</label>
                                <input type="text" name="city" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Alamat Lengkap</label>
                                <textarea name="address" class="form-control" rows="3" required></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Link Google Maps</label>
                                <input type="text" name="maps_link" class="form-control" placeholder="https://goo.gl/maps/..." required>
                            </div>
                            <div class="mb-4">
                                <label class="form-label fw-bold">Foto Depan Toko</label>
                                <input type="file" name="foto" class="form-control" required>
                                <div class="form-text">Format: JPG/PNG. Pastikan foto landscape.</div>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" name="submit" class="btn btn-dark rounded-pill py-2 fw-bold">Publish Cabang</button>
                                <a href="admin.php" class="btn btn-light rounded-pill py-2">Batal</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>