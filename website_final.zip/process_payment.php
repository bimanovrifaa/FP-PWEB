<?php
// process_payment.php
include 'koneksi.php';

// --- KONFIGURASI MIDTRANS (MODE SANDBOX / TUGAS) ---
// Masukkan Server Key baru yang berawalan "SB-Mid-server-..."
$serverKey = 'Mid-server-v7HhlAwRcVy7TapB1INsUIiZ'; 

// Set ke false karena kita mau mode Sandbox/Test
$isProduction = false; 

$apiUrl = $isProduction 
    ? 'https://app.midtrans.com/snap/v1/transactions' 
    : 'https://app.sandbox.midtrans.com/snap/v1/transactions';

// Terima Data dari Frontend
$json = file_get_contents('php://input');
$data = json_decode($json, true);

if(!$data) {
    echo json_encode(['error' => 'Data tidak valid']);
    exit;
}

// Data Pesanan
$orderId = 'TETRA-' . time() . '-' . rand(100, 999);
$totalAmount = (int)$data['total']; // Pastikan integer
$name = $data['name'];
$phone = $data['phone'];
$address = $data['address'];

// 1. Simpan ke Database
$query = "INSERT INTO orders (order_id, customer_name, customer_phone, customer_address, total_amount, status) 
          VALUES ('$orderId', '$name', '$phone', '$address', '$totalAmount', 'pending')";

if(!mysqli_query($conn, $query)) {
    echo json_encode(['error' => 'Gagal simpan database: ' . mysqli_error($conn)]);
    exit;
}

// 2. Siapkan Parameter Midtrans
$params = [
    'transaction_details' => [
        'order_id' => $orderId,
        'gross_amount' => $totalAmount,
    ],
    'customer_details' => [
        'first_name' => $name,
        'phone' => $phone,
        'address' => $address, // Midtrans butuh billing address, kita pakai ini dulu
    ]
];

// 3. Kirim ke Midtrans via cURL
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => $apiUrl,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => json_encode($params),
    CURLOPT_HTTPHEADER => [
        'Accept: application/json',
        'Content-Type: application/json',
        'Authorization: Basic ' . base64_encode($serverKey . ':')
    ],
]);

$response = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);

if ($err) {
    echo json_encode(['error' => 'Koneksi Midtrans Gagal: ' . $err]);
} else {
    $result = json_decode($response, true);
    if(isset($result['token'])) {
        $token = $result['token'];
        // Update token di database
        mysqli_query($conn, "UPDATE orders SET snap_token='$token' WHERE order_id='$orderId'");
        echo json_encode(['token' => $token]);
    } else {
        // Tampilkan error detail dari Midtrans jika gagal
        echo json_encode(['error' => 'Midtrans Error', 'details' => $result]);
    }
}
?>